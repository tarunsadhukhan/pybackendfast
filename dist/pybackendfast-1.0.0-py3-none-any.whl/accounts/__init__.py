# inventory/__init__.py
from .routes import router

__all__ = ["router"]
